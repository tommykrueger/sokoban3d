<?php

// Force document to be UTF-8
header('Content-Type: text/html; charset=utf-8');

// BASIC DATABASE SETTINGS PARAMETERS
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_NAME", "terror_incidents");
define("DB_CHARSET", "utf8");
define("DB_PREFIX",	"");

?>