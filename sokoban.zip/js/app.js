import Log from './app/log';
import ThreeScene from './components/threescene.js';

export default class App {
  
  constructor () {

    this.resolutions = {

      low: {

        sphereSegments: 32

      },

      high: {

        sphereSegments: 128

      }

    }


    this.defaultOptions = {

      // the level of detail
      resolution: this.resolutions['low'],

      // rendering mode
      view: '3d',

      // render statistics as well
      renderStats: true,

    };


    this.setDevelopmentMode();
    this.init();

  }


  init () {

    this.THREESCENE = new ThreeScene(this.defaultOptions);

  }


  setResolution (resolution = 'low') {

    this.defaultOptions.resolution = this.resolutions[resolution];

  }


  setDevelopmentMode () {

    window.isDevelopmentMode = true;

  }

};

new App();
export var __useDefault = true;

export default class Log {

  init () {}

  info (message) {
  	this.print(message, 'info');
  }

  error (message) {
		this.print(message, 'error');
  }

  print (message, type = 'info') {
  	if (typeof(console) === 'object' && window.console.log) {
  		console.log(message);
  	}
  }
}
import THREE from 'three.js';

export var __useDefault = true;


/**
 * Utility class to be used for global functions
 */

export default class Utils {

	constructor() {

		// the distance of one astronomical unit in kilometers
		this.AU = 149597870.700;

		// the distance for one light year in km
		this.LY = 9460730472580.800;

		// the distance of one parsec in light years
		this.PC = 3.26156;

		// define how large 1px is in comparison to the the real world size
		// every distance will be divided by this value
		this.distancePixelRatio = Math.round(149597870.700 / 10.0);


		// set the default rotation time in days for stars
		this.defaultStarRotationPeriod = 25.00;

		this.radiusSun = 696342; // km


		this.radiusEarth = 6371;

		// For stars
		this.radiusStarPixelRatio = 100000000;

		// For planets, moons, etc
		this.radiusPixelRatio = 50000;


		this.planetDefaultColor = [0, 0, 200];


		this.orbitTransparency = 0.5;

		this.orbitColors = [
			0xD59C6F,
			0x88bf8b,
			0x4682b4,
			0xd2691e,
			0xf0e68c,
			0xffa500,
			0xE89296,
			0x92DEE8,
			0x55732D,
			0x0FF7E8,

			0xE3B1E0,
			0xCA8E40,
			0x983315,
			0xA06E00,
			0xFFB100,
			0xFF6202,
			0x00579E,
			0x9E600A,
			0xFFA301,
			0x913E20
		];



		this.spectralColors = {
			'o': 0x9BB0FF, // blue
			'b': 0xBBCCFF, // blue white
			'a': 0xFBF8FF, // white
			'f': 0xFFFFF0, // yellow white
			'g': 0xFFFF00, // yellow
			'k': 0xFF9833, // orange
			'm': 0xBB2020, // red
			'l': 0xA52A2A, // red brown
			't': 0x964B00, // brown
			'y': 0x663300  // dark brown
		};


	}

	getDistance( distance, distanceType = 'ly' ) {

		if (distanceType.toLowerCase() == 'ly') {
			return (distance * this.LY / this.distancePixelRatio);
		}	

		if (distanceType.toLowerCase() == 'au') {
			return (distance * this.AU / this.distancePixelRatio);
		}

	}


	/**
	 * project from 3d to 2d space
	 */ 
	toScreenPosition(obj, camera) {

    var vector = new THREE.Vector3();

    var widthHalf = 0.5 * window.innerWidth;
    var heightHalf = 0.5 * window.innerHeight;

    obj.updateMatrixWorld();
    vector.setFromMatrixPosition(obj.matrixWorld);
    vector.project(camera);

    vector.x = ( vector.x * widthHalf ) + widthHalf;
    vector.y = - ( vector.y * heightHalf ) + heightHalf;

    return { 
      x: vector.x,
      y: vector.y
    };

	}


	project2D (mesh, app) {

		app.scene.updateMatrixWorld(true);

		var position = new THREE.Vector3();
		var pos = position.setFromMatrixPosition( mesh.matrixWorld );
		
		app.camera.updateMatrixWorld(true);

		// var vector = app.projector.projectVector(pos.clone(), app.camera);
		var vector = pos.unproject(app.camera);

		var pLocal = new THREE.Vector3(0, 0, -1);
		var pWorld = pLocal.applyMatrix4( app.camera.matrixWorld );
		var dir = pWorld.sub( app.camera.position ).normalize();

		var scalar = (pos.x - app.camera.position.x) / dir.x;
		// window.utils.debug( scalar );
		if (mesh.name == 'Earth') {
  		// window.utils.debug('Earth pos', scalar);
  	}

	  if (scalar < 0) {
	  	console.log(mesh.name);
	  	// window.utils.debug('object behind camera');
	  	// return false; // this means the point was behind the camera, so discard
	  }

		vector.x = (vector.x + 1)/2 * window.innerWidth;
		vector.y = -(vector.y - 1)/2 * window.innerHeight;

		return vector;
	}



	// taken from: http://zachberry.com/blog/tracking-3d-objects-in-2d-with-three-js/
	getPosition2D ( object, app ) {

		app.scene.updateMatrixWorld(true);

		var p, v, percX, percY, left, top;

		// this will give us position relative to the world
		p = object.position.clone();

		app.camera.updateMatrixWorld(true);

		// unproject will translate position to 2d
		v = p.unproject(app.camera);

		// Pick a point in front of the camera in camera space:
		var pLocal = new THREE.Vector3(0, 0, -1);

		// Now transform that point into world space:
		var pWorld = pLocal.applyMatrix4( app.camera.matrixWorld );
		
		// You can now construct the desired direction vector:
		var dir = pWorld.sub( app.camera.position ).normalize();

		var scalar = (p.x - app.camera.position.x) / dir.x;
		//window.utils.debug( scalar );

	  if (scalar < 0) {
	  	// window.utils.debug('object behind camera');
	  	// return false; //this means the point was behind the camera, so discard
	  }
		//window.utils.debug( v );

		// translate our vector so that percX=0 represents
		// the left edge, percX=1 is the right edge,
		// percY=0 is the top edge, and percY=1 is the bottom edge.
		v.x = (v.x + 1)/2 * window.innerWidth;
		v.y = -(v.y - 1)/2 * window.innerHeight;

		return v;

	}


	toRad() {

		return Math.PI / 180;

	}


	// derived from: https://github.com/mrdoob/three.js/blob/master/examples/js/Detector.js
  isWebGLSupported() {

    try {
      
      let canvas = document.createElement("canvas");
      return !! window.WebGLRenderingContext && (canvas.getContext("webgl") || canvas.getContext("experimental-webgl"));

    } catch(e) { return false; } 

  }

  // taken from: http://stackoverflow.com/questions/3177855/how-to-format-numbers-similar-to-stack-overflow-reputation-format
	numberFormat(number) {
		var repString = number.toString();

	  if ( number < 1000 ) {
			repString = number;
	  } else if ( number < 1000000 ) {
			repString = (Math.round((number / 1000) * 10) / 10) + ' K'
	  } else if ( number < 1000000000 ) {
			repString = (Math.round((number / 1000000) * 10) / 10) + ' Mio'
	  } else if ( number < 1000000000000000000 ) {
			repString = (Math.round((number / 1000000000) * 10) / 10) + ' Bio'
	  }

	  return repString;
	}



	getDimensionToTen( min, max ) {

		var size = Math.ceil( max * 100000 ) / 100000;

		if( max < 0.001 )
			size = Math.ceil( max * 10000 ) / 10000;
		else if( max < 0.01 )
			size = Math.ceil( max * 1000 ) / 1000;
		else if( max < 0.1 )
			size = Math.ceil( max * 100 ) / 100;
		else if( max < 1 )
			size = Math.ceil( max * 10 ) / 10;

		else {
			size = Math.ceil( max );
		}

		return {
			size: size,
			max: max,
			min: min,
			minPercent: Math.round(min * 100 / size) / 100,
			maxPercent: Math.round(max * 100 / size) / 100
		}

	}


  debug(txt) {

  	if (window.isDevelopmentMode)
  		console.log(txt);

  }


  // taken from: http://jsfiddle.net/Brfp3/3/
	textCircle (ctx, text, x, y, radius, space, top){
	   space = space || 0;
	   var numRadsPerLetter = (Math.PI - space * 2) / text.length;
	   ctx.save();
	   ctx.translate(x,y);
	   var k = (top) ? 1 : -1; 
	   ctx.rotate(-k * ((Math.PI - numRadsPerLetter) / 2 - space));
	   for(var i=0;i<text.length;i++){
	      ctx.save();
	      ctx.rotate(k*i*(numRadsPerLetter));
	      ctx.textAlign = "center";
	     	ctx.textBaseline = (!top) ? "top" : "bottom";
	     	ctx.fillText(text[i],0,-k*(radius));
	      ctx.restore();
	   }
	   ctx.restore();
	}


}
export var __useDefault = true;

import Utils from './utils';

import Template from '../views/template';

/**
 * View base class
 * Used for all DOM - related objects
 * 
 */

export default class View {

	constructor ( options = {} ) {

		this.options = options;
		this.app = options.app;

		this.utils = new Utils();
		
		this.name = '';
		this.$view = ``;

	}

	setData() {

	}

	render() {

		this.$el = this.$view;
		return this.$el;

	}

	getHtml() {

		return this.$el.html();

	}

	appendTo( $element ) {



	}

}
import THREE from 'three.js';
import _ from 'underscore';
import Utils from '../app/utils';

export default class Character {


	constructor (options = {}) {

		this.options = options;
		this.app = this.options.app;
    this.level = this.options.level;

    this.delta = 1;

		this.utils = new Utils();

	}
 

  render () {

  	var cMaterial = new THREE.MeshLambertMaterial({
  		color: 0xff0000, 
  		transparent: false,
  		opacity: 1,
  		side: THREE.DoubleSide,
  		blending: THREE.AdditiveBlending 
  	});

    this.character = new THREE.Mesh(
    	new THREE.BoxGeometry(1, 1, 1),
   		cMaterial
   	);

    // this.box.position.set(-1, 0, 1);
    this.character.castShadow = true;

		this.app.scene.add( this.character );


    this.initControls();

  }


  setPosition(pos) {

    this.character.position.set(pos.x, pos.y, pos.z);

  }



  initControls () {

    document.addEventListener('keydown', (e) => this.keyDown(e), false);

  }


  keyDown(event) {

    event = event || window.event;

    var keycode = event.keyCode;

    switch(keycode){
        case 37: //left arrow
        //this.box.position.x -= delta;
        this.move('left');
      break;
        case 38: // up arrow
        //this.box.position.z -= delta;
        this.move('up');
      break;
        case 39: // right arrow
        //this.box.position.x += delta;
        this.move('right');
      break;
        case 40: //down arrow
        //this.box.position.z += delta;
        this.move('down');
      break;
    }

  }


  move (direction = 'down') {

    if (this.canMove(direction)) {

      if (direction == 'left') {
        this.character.position.x -= this.delta; 
      }

      if (direction == 'right') {
        this.character.position.x += this.delta; 
      }

      if (direction == 'up') {
        this.character.position.z -= this.delta; 
      }

      if (direction == 'down') {
        this.character.position.z += this.delta; 
      }

      this.level.checkOnLift(this.character.position);
      this.level.checkSolved();

    }

  }


  // check if there is an obstacle before moving
  canMove (direction) {

    let currentPosition = this.character.position; 

    let targetPosition = new THREE.Vector3(this.character.position); 
        targetPosition.x = this.character.position.x;
        targetPosition.y = this.character.position.y;
        targetPosition.z = this.character.position.z;

    let targetFrontPosition = new THREE.Vector3(targetPosition.x, targetPosition.y, targetPosition.z); 


    if (direction == 'left') {
      targetPosition.x -= this.delta;
      targetFrontPosition.x -= this.delta * 2;
    }

    if (direction == 'right') {
      targetPosition.x += this.delta; 
      targetFrontPosition.x += this.delta * 2;
    }

    if (direction == 'up') {
      targetPosition.z -= this.delta; 
      targetFrontPosition.z -= this.delta * 2;
    }

    if (direction == 'down') {
      targetPosition.z += this.delta; 
      targetFrontPosition.z += this.delta * 2;
    }

    if (this.level.hasObjectAtPosition(targetPosition, 'wall')) {
      return false;
    }

    if (this.level.hasObjectAtPosition(targetPosition, 'box')) {

      let mesh = this.level.getObjectAtPosition(targetPosition, 'box');
      
      // check if in font of the box is a fee place
      if (!this.level.hasObjectAtPosition(targetFrontPosition, 'wall') && !this.level.hasObjectAtPosition(targetFrontPosition, 'box')) {

        // move the box also
        this.level.moveObject(mesh, targetFrontPosition);

      } else {

        return false;

      }

    }

    return true;

  }


}
import THREE from 'three.js';
import _ from 'underscore';
import Utils from '../app/utils';
import Character from './character';


export default class Level {


	constructor (options = {}) {

		this.options = options;
		this.app = this.options.app;
		this.level = this.options.level;

		this.utils = new Utils();

    this.boxes = [];
    this.floors = [];
		this.meshes = [];

    this.targets = 0;

    this.floor = new THREE.Group();
    this.currentFloor = 0;

		this.materials = {

			wall: new THREE.MeshLambertMaterial({
	  		color: 0x116796, 
	  		transparent: false,
	  		opacity: 1,
	  		side: THREE.DoubleSide,
	  		blending: THREE.AdditiveBlending 
	  	}),

	  	floor: new THREE.MeshLambertMaterial({
	  		color: 0x666666, 
	  		transparent: false,
	  		opacity: 1,
	  		side: THREE.DoubleSide,
	  		blending: THREE.AdditiveBlending 
	  	}),

	  	target: new THREE.MeshLambertMaterial({
	  		color: 0x11ee11, 
	  		transparent: true,
	  		opacity: .1,
	  		side: THREE.DoubleSide,
	  		blending: THREE.AdditiveBlending 
	  	}),

	  	box: new THREE.MeshLambertMaterial({
	  		color: 0xF4A460, 
	  		transparent: false,
	  		opacity: 1,
	  		side: THREE.DoubleSide,
	  		blending: THREE.AdditiveBlending 
	  	}),

      lift: new THREE.MeshLambertMaterial({
        color: 0x90ff00, 
        transparent: false,
        opacity: 1,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending 
      })


		};

	}
 

  render () {

  	if (this.level.floors) {

      var index = 0;

      this.level.floors.forEach(( floor, f ) => {

        var floorGroup = new THREE.Group();
        this.floors.push(floorGroup);


    		floor.map.forEach(( row, i ) => {
    			
    			row.forEach(( col, j ) => {

            let pos = new THREE.Vector3( i, 0, j );
            let type = '';

    				switch(col) {

    					case '#':
    						this.renderWall(pos);
                type = 'wall';
    						break;

  						case '.':
    						this.renderTarget(pos);
                type = 'target';
    						break;

  						case '@':
    						this.renderCharacter(pos);
                type = 'character';
    						break;

  						case 'b':
    						this.renderBox(pos);
                type = 'box';
    						break;

              case 'l':
                this.renderLift(pos);
                type = 'lift';
                break;
    				}

            index++;

  				});

  			});  

      });       

  	}


  	var object = new THREE.Object3D();

    var plane = new THREE.Mesh(
    	new THREE.PlaneGeometry(10, 10),
   		this.materials.floor
   	);

   	plane.receiveShadow = true;
   	//box.castShadow = true;

   	plane.position.y = -.51;
   	plane.rotation.x = Math.PI / 2;

		this.app.scene.add( plane );
    // this.app.scene.add( this.floo );

  }


  renderWall (pos) {

  	var wall = new THREE.Mesh(
    	new THREE.BoxGeometry(1, .5, 1),
   		this.materials.wall
   	);

   	wall.castShadow = true;
   	wall.position.set(pos.x, 0, pos.z);
    wall.objectType = 'wall';

    this.meshes.push(wall);
   	this.app.scene.add( wall );

  }


  renderTarget (pos) {

  	var target = new THREE.Mesh(
    	new THREE.BoxGeometry(1, 1, 1),
   		this.materials.target
   	);

   	target.castShadow = true;
   	target.position.set(pos.x, pos.y, pos.z);
    target.objectType = 'target';

    this.meshes.push(target);
    this.targets++;
   	this.app.scene.add(target);

  }


  renderCharacter (pos) {

  	this.character = new Character({app: this.app, level: this});
  	this.character.render();
  	this.character.setPosition(pos);

  }


  renderBox (pos) {

  	var box = new THREE.Mesh(
    	new THREE.BoxGeometry(1, 1, 1),
   		this.materials.box
   	);

   	box.castShadow = true;
   	box.position.set(pos.x, pos.y, pos.z);
    box.objectType = 'box';

    this.meshes.push(box);
   	this.app.scene.add( box );

  }


  renderLift (pos) {
    var lift = new THREE.Mesh(
      new THREE.BoxGeometry(1, .25, 1),
      this.materials.lift
    );

    lift.castShadow = true;
    lift.position.set(pos.x, pos.y, pos.z);
    lift.objectType = 'lift';

    this.meshes.push(lift);
    this.app.scene.add( lift );
  }




  hasObjectAtPosition (pos, objectType) {

    let toreturn = false;

    this.meshes.forEach((mesh) => {

      if (mesh.position.distanceTo(pos) == 0 && mesh.objectType == objectType) {
        toreturn = mesh;
      }

    });

    return toreturn;

  }


  getObjectAtPosition (pos, objectType) {

    let toreturn = false;
    this.meshes.forEach((mesh) => {

      if (mesh.position.distanceTo(pos) == 0 && mesh.objectType == objectType) {
        toreturn = mesh;
      }

    });

    return toreturn;

  }


  moveObject (mesh, targetPosition) {

    mesh.position.x = targetPosition.x;
    mesh.position.y = targetPosition.y;
    mesh.position.z = targetPosition.z;

  }



  goToFloor () {
    
  }
  


  checkOnLift (pos) {

    let isOnLift = false;

    this.meshes.forEach((mesh) => {

      if (mesh.position.distanceTo(pos) == 0 && mesh.objectType == 'lift') {
        isOnLift = true;
      }

    });

    if (isOnLift) {
      this.app.$button.activate();
    } else {
      this.app.$button.deactivate();
    }

  }


  checkSolved () {

    let solved = true;
    let targetsWithBoxes = 0;

    this.meshes.forEach((p1) => {

      this.meshes.forEach((p2) => {

        if (p1.objectType == 'target' && p2.objectType == 'box') {

          if (p1.position.distanceTo(p2.position) == 0) {
            targetsWithBoxes++;
          }

        }

      });   

    });  

    if (this.targets === targetsWithBoxes) {
      console.log('stage solved ', solved, targetsWithBoxes);
    }

  }


}
import $ from 'jquery';
import THREE from 'three.js';

export var __useDefault = true;

export default class Shader {


	constructor ( options = {} ) {

		this.options = options;

		this.shader = this.options.shader;
		this.uniforms = this.options.uniforms || [];
		this.attributes = this.options.attributes || [];

		this.isAnimateable = true;
		this.material = null;

		this.materials = {
			vertex: '',
			fragment: ''
		}

		this.i = 2;

	}


	load ( callback = {} ) {

		this.call({
			url: '../src/js/shaders/vertex-shader-'+ this.shader +'.js',
			shaderType: 'vertex',
			callback: callback
		});

		this.call({
			url: '../src/js/shaders/fragment-shader-'+ this.shader +'.js',
			shaderType: 'fragment',
			callback: callback
		});

	}


	getMaterial () {
		return this.material;
	}


	setMaterial () {

		this.material = new THREE.ShaderMaterial({  
		  uniforms: this.uniforms,
		  vertexShader: this.materials['vertex'],
		  fragmentShader: this.materials['fragment'],

			blending: THREE.NormalBlending,

		  transparent: true,
		  depthTest: false,
		  depthWrite: false
		});


		// this.uniforms.tNoise.value.wrapS = this.uniforms.tNoise.value.wrapT = THREE.RepeatWrapping;

	}


	setAttributes ( attributes = {} ) {
		this.attributes = attributes;
	}






	call ( options = {} ) {

		$.ajax({
			url: options.url,
			dataType: 'text',
			async: false,
			success: (data) => {

				this.materials[options.shaderType] = data;
				this.i--;

				if (this.i == 0) {
					this.setMaterial();
					options.callback(data);
				}

			}
		});

	}

}
import $ from 'jquery';
import _ from 'underscore';
import THREE from 'three.js';
import Stats from 'stats';

import Utils from '../app/utils';

import Character from '../components/character';
import Level from '../components/level';


import Button from '../views/button';

export default class ThreeScene {
  
  constructor (options = {}) {

  	this.utils = new Utils();
  	this.options = options;

  	this.meshes = [];

  	this.raycaster = new THREE.Raycaster();
  	this.mouse = new THREE.Vector2();

  	// to be optimized
  	this.time = Date.now();
		this.simTime = this.time;
		this.simTimeSecs = null;

		this.defaultSpeed = 100;

		this.startTime = _.now();

		// current speed (1 earth day represents 365/100 seconds in app)	
		this.currentSpeed = 100;
		this.speedStep = 100;

		this.date = new Date( this.simTime );
		this.timeElapsedSinceCameraMove = 0;
		this.timeElapsed = 0;


		this.clock = new THREE.Clock();
		this.delta = 0;
		this.timeElapsed = 0;


  	this.center = new THREE.Vector3(0,0,0);

  	this.prepareScene();
    this.init();

  }

  prepareScene() {

  	this.scene = new THREE.Scene();
		this.renderer;
		this.camera; 
		this.cameraControls;
		this.controls;
		//this.projector;

  	if (this.utils.isWebGLSupported()) {

			this.renderer = new THREE.WebGLRenderer({
				antialias: true
			});

			this.renderer.setClearColor( 0x000000, 1 );

		} else {

			let message = new Message({text: 'No WebGL', state: 'info'});
					message.render();

			return;
		}


		this.initCamera();


		// the position which the camera is currently looking at
		this.cameraTarget = new THREE.Vector3(0,0,0);

		// the current center position (planet systems will be rendered to this point)
		this.center = new THREE.Vector3(0,0,0);

		// this.cameraHelper = new CameraHelper({ app: self });

		this.renderer.setSize( window.innerWidth, window.innerHeight );
		this.renderer.shadowMap.enabled = true;
		this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

		/*
		this.renderer.shadowCameraNear = 3;
    this.renderer.shadowCameraFar = this.camera.far;
    this.renderer.shadowCameraFov = 50;

    this.renderer.shadowMapBias = 0.0039;
    this.renderer.shadowMapDarkness = 0.5;
    this.renderer.shadowMapWidth = 1024;
    this.renderer.shadowMapHeight = 1024;

    */

		this.container = document.getElementById('scene');
		this.container.appendChild(this.renderer.domElement);

	  // add event listeners
	  document.addEventListener( 'mousedown', (e) => this.onDocumentMouseMove(e), false );
	  document.addEventListener( 'mousemove', (e) => this.onDocumentMouseMove(e), false );
	  document.addEventListener( 'mouseover', (e) => this.onDocumentMouseMove(e), false );

  }


  init() {

  	// this.initCamera();
		this.initLighting();
		this.initResize();

    if (this.options.renderStats)
	  	this.renderStats();

	  //this.loadLevel('level1');
	  //this.loadLevel('level2');
	  this.loadLevel('level3');

	  this.renderViews();


	  this.animate();

  }



  initCamera( target ) {

  	var self = this;

  	if (target !== undefined || target != null)
  		self.cameraTarget = target;

  	var width = $(window).width();
  	var height = $(window).height();

  	// add the camera to the scene
		this.camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, .1, 1000 );
		//this.camera = new THREE.OrthographicCamera( width / - 2, width / 2, height / 2, height / - 2, 1, 1000 );
		this.camera.updateProjectionMatrix();

		//this.cameraHelper = new THREE.CameraHelper(this.camera);
		//this.scene.add(this.cameraHelper);

		this.utils.debug('current camera target', self.cameraTarget);

		if (this.options.view == '3d') {

			let pos = { x: 0 };

			pos.y = 18;
			pos.z = 18;

			console.log('rendering camera at:', pos.x, pos.y, pos.z);

			this.camera.position.set( pos.x, pos.y, pos.z );

		}
		
		this.scene.add(this.camera);
		// this.controls = new THREE.TrackballControls( this.camera, this.container );

		this.controls = new THREE.OrbitControls( this.camera, this.container );

		//var vector = new THREE.Vector3( this.controls.target.x, this.controls.target.y, this.controls.target.z );
  			//vector.applyQuaternion( this.camera.quaternion );

  	this.cameraTarget = this.controls.target;

		if (target !== undefined || target != null) {
			// window.utils.debug('defining new camera target', target);

			// define the camera position
			this.cameraHelper.setCameraPosition(target);	

			// define the target which the camera shoul look at
			//this.cameraHelper.setCameraTarget(target);

		} else {
			this.camera.lookAt(this.cameraTarget);
			//this.cameraHelper.setCameraTarget( self.cameraTarget );
		}


		this.cameraPosition = new THREE.Vector3();
		this.cameraPosition = this.cameraPosition.setFromMatrixPosition( this.camera.matrixWorld );
		this.cameraPositionOld = this.cameraPosition;

	  this.controls.rotateSpeed = .5;
	  this.controls.zoomSpeed = 1.8;
	  this.controls.panSpeed = .3;

	  //this.controls.minDistance = this.window.utils.makeDistance( 0.0001, 'au');

	  //this.controls.noZoom = false;
	  //this.controls.noPan = false;

	  this.controls.enableDamping = false;
	  this.controls.dampingFactor = 0.3;

	  this.controls.keys = [];
	  this.controls.addEventListener( 'change', this.render() );
  }


	initLighting() {

	  // add a very light ambient light
	  var globalLight = new THREE.AmbientLight(0xffffff);

	  globalLight.color.setRGB( 
	  	.521,
	  	.521,
	  	.521
	  );

	  this.scene.add( globalLight );


	  //directional light
		this.directionalLight = new THREE.DirectionalLight(0xffffff, 1.75);
		this.directionalLight.position.set(-6, 6, 11);
		this.directionalLight.target.position.set(1, 1, 0);
		 
		this.directionalLight.castShadow = true;
		// this.directionalLight.shadowCameraVisible = true;
		//this.directionalLight.shadowDarkness = 0.5;

		//this.directionalLight.shadow.mapSize.width = 512 * 2;
    //this.directionalLight.shadow.mapSize.height = 512 * 2;
		 
		this.directionalLight.shadow.camera.near = 0;
		this.directionalLight.shadow.camera.far = 1000;
		 
		this.directionalLight.shadow.camera.left = -20;
		this.directionalLight.shadow.camera.right = 20;
		this.directionalLight.shadow.camera.top = 20;
		this.directionalLight.shadow.camera.bottom = -20;
 
		this.scene.add(this.directionalLight);

		//var lightHelper3 = new THREE.DirectionalLightHelper( this.directionalLight );
		//this.scene.add( lightHelper3 );
  }


  loadLevel (level) {
		var self = this;

		$.ajax({
		  url: './src/json/'+ level +'.json?time=' + Math.random(),
		  dataType: 'json',
		  success: (level) => {

		  	console.log(level);
		  	
		  	this.level = new Level({
		  		app: this, 
		  		level: level
		  	});

		  	this.level.render();

		  	//this.character = new Character({app: this});
		  	//this.character.render();

		  }
		});

	}


	renderViews() {

		this.$button = new Button({
			app: this,
			data: {
				name: 'Lift',
				type: 'lift'
			}
		});

	}


  renderStats ( container = $('body') ) {
  	this.stats = new Stats();

  	$(this.stats.domElement).attr('class', 'stats');
  	$(this.stats.domElement).css({
			'position': 'absolute',
			'bottom': '0',
			'z-index': 99
		});

		container.append( this.stats.domElement );
  }



  initResize() {

		window.addEventListener('resize', () => {

      let w = window.innerWidth;
      let h = window.innerHeight;

      this.renderer.setSize( w, h );
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
    });

  }


	animate ( step ){
  	this.timeElapsed = step;

    // loop on request animation loop
		// - it has to be at the begining of the function
		// - see details at http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating
		requestAnimationFrame( this.animate.bind( this ) );
		this.controls.update();


	  // set the time
	  this.lastTime = this.time;
	  this.time = Date.now();
	  this.dt = this.time - this.lastTime;
	  this.simTime += this.dt * this.currentSpeed;
	  this.date = new Date(this.simTime);
	  this.simTimeSecs = this.simTime;

		// do the render
		this.render(step);

		// update stats
		if (this.options.renderStats)
			this.stats.update();
  }


  render (step) {
		var self = this;

		this.delta = this.clock.getDelta();
		this.timeElapsed = this.clock.getElapsedTime();

		// this.renderCount++;
		var now = _.now();
		var currentDate = new Date(now - this.startTime);
		var secondsElapsed = currentDate.getSeconds();
		var minutesElapsed = currentDate.getMinutes();
		// window.utils.debug('time since app start', minutesElapsed + 'm ' + secondsElapsed + 's');

		this.currentRenderLoops++;

		// calculate current distance from solar center
		this.cameraPosition = new THREE.Vector3();
		this.cameraPosition = this.cameraPosition.setFromMatrixPosition( this.camera.matrixWorld );

		// distance in px
		this.distanceCamera = this.cameraPosition.distanceTo( self.cameraTarget );

		// check if camera position changed and recalculate star sizes
		if (this.cameraPosition.y != this.cameraPositionOld.y) {
			this.cameraPositionOld = this.cameraPosition;
			this.timeElapsedSinceCameraMove = now;
		}

		// Move the camera in a circle with the pivot point in the center of this circle...
	  // ...so that the pivot point, and focus of the camera is on the center of the scene.
	  if ((now - this.timeElapsedSinceCameraMove) > 30000) {
			// this.cameraHelper.autoRotation();
	  }


	  // this.cameraHelper.update();

		// TWEEN.update();
		this.renderer.render( this.scene, this.camera );
	}


  onDocumentMouseMove(e) {

		e.preventDefault();

		this.updateMousePosition(e);

		//var self = this;
		//var vector = new THREE.Vector3( ( e.clientX / window.innerWidth ) * 2 - 1, - ( e.clientY / window.innerHeight ) * 2 + 1, .5 );
		// this.projector.unprojectVector( vector, this.camera );

		//vector.unproject(this.camera);

		//var rayCaster = new THREE.Raycaster( this.camera.position, vector.sub( this.camera.position ).normalize() );
	

		/*
		_.each( self.markers, function( marker, idx ){
			self.scene.remove( marker );
		});
		*/

		
		// var intersects = rayCaster.intersectObjects( this.meshes, true );


		//  check intersection of stars
		this.intersectStars(e);

		// var mouse = { x: 0, y: 0, z: 1 };

		

		// this where begin to transform the mouse cordinates to three.js cordinates
	  // mouse.x = ( e.clientX / window.innerWidth ) * 2 - 1;
	  // mouse.y = - ( e.clientY / window.innerHeight ) * 2 + 1;
	    
	  // this vector caries the mouse click cordinates
	  //var mouse_vector = new THREE.Vector3(0,0,0);
	  		//mouse_vector.set( mouse.x, mouse.y, mouse.z );

	 	// this.projector.unprojectVector( mouse_vector, this.camera );
	  
	  //mouse_vector.unproject(this.camera);

	  //var direction = mouse_vector.sub( this.camera.position ).normalize();
	  //rayCaster.set( this.camera.position, direction );
	    


		// check if the user moves the mouse over a planet or host star
		/*
		_.each( this.meshes, function( mesh, idx ){
			//window.utils.debug(mesh);
			if( mesh.position ) {
				intersects = rayCaster.intersectObject( [mesh] );

				if( intersects.length > 0 ) {
	  			window.utils.debug( intersects[ 0 ].object );
	  		}
			}
		});
		*/

		// s$('#tooltip').hide();
		// self.canvasElement.hideViewHelper();
		// this.checkStarMouseCollision(e);

	}


	updateMousePosition ( e ) {

		this.mouse.x = ( e.clientX / window.innerWidth ) * 2 - 1;
		this.mouse.y = - ( e.clientY / window.innerHeight ) * 2 + 1;

	}


	/**
	 * track mouse movement over stars
	 */
	intersectStars (e) {

		if (this.particles) {

			this.raycaster.setFromCamera( this.mouse, this.camera );

			let intersects = this.raycaster.intersectObject( this.particles );
			let INTERSECTED;

			if ( intersects.length > 0 ) {

				if ( INTERSECTED != intersects[ 0 ].index ) {

					INTERSECTED = intersects[ 0 ].index;

					// console.log(intersects[ 0 ]);
					console.log( this.loadedStars[INTERSECTED] );

					this.canvasElement.updatePosition({
						x: e.clientX,
						y: e.clientY
					});
					
					this.canvasElement.registerObject(this.loadedStars[INTERSECTED]);
					this.canvasElement.showTooltip();
					this.canvasElement.show();

				}

			} else if ( INTERSECTED !== null ) {

				INTERSECTED = null;
				this.canvasElement.hide();
				this.canvasElement.hideTooltip();

			}

		}

	}



	checkStarMouseCollision (e) {


		if (!this.isMouseOverElement(e)) {

			// check if user moves the mouse near a star
			this.stars.forEach(( star, idx ) => {

				if (star) {

					var pos = this.utils.getPosition2D( star, this );

					
					if (star.properties.id <= 100) {
						// console.log(pos.x);
					}

					if ( pos.x >= (e.clientX - 5) && pos.x <= (e.clientX + 5) ) {
						if ( pos.y >= (e.clientY - 5) && pos.y <= (e.clientY + 5) ) {

							console.log('star hovered');

							this.canvasElement.updatePosition(pos);
							this.canvasElement.updateObjectInfo(star);
							this.canvasElement.showTooltip();
							this.canvasElement.showViewHelper();

						}
					}

				}

			});

		}

	}


	// check over which element the mouse is
	isMouseOverElement (event){
		let el = document.elementFromPoint(event.clientX, event.clientY);
    return !$(el).is('canvas') && !$(el).hasClass('habitable-star-label');
	} 


}


//# sourceMappingURL=app.js.map
