import THREE from 'three.js';
import _ from 'underscore';
import Utils from '../app/utils';

export default class Character {


	constructor (options = {}) {

		this.options = options;
		this.app = this.options.app;
    this.level = this.options.level;
    this.position = this.options.position;

    this.delta = 1;
    this.currentPosition = { x: 0, y: 0 };

		this.utils = new Utils();

	}
 

  render () {

  	var cMaterial = new THREE.MeshLambertMaterial({
  		color: 0xff0000, 
  		transparent: false,
  		opacity: 1,
  		side: THREE.DoubleSide,
  		blending: THREE.AdditiveBlending 
  	});

    this.character = new THREE.Mesh(
    	new THREE.BoxGeometry(.1, .1, .1),
   		cMaterial
   	);


    this.mesh = new THREE.Mesh(
      new THREE.SphereGeometry(.5, 32, 32),
      cMaterial
    );

    this.mesh.castShadow = true;

    this.setPosition();
    this.initControls();

  }


  animate (clock) {

    let t = Math.sin(clock.getElapsedTime() * 3);
    let scale = Math.max(.8, t);

    this.mesh.scale.x = scale;
    this.mesh.scale.y = scale;
    this.mesh.scale.z = scale;

  }


  setPosition (position = false) {

    if (position) this.position = position;
    this.mesh.position.set(this.position.x, this.position.y, this.position.z);

  }



  initControls () {

    document.addEventListener('keydown', (e) => this.keyDown(e), false);

  }


  getMesh() { 
    return this.mesh;
  }


  keyDown(event) {

    event = event || window.event;

    var keycode = event.keyCode;

    switch(keycode){
        case 37: // left arrow
        this.move('left');
      break;
        case 38: // up arrow
        this.move('up');
      break;
        case 39: // right arrow
        this.move('right');
      break;
        case 40: // down arrow
        this.move('down');
      break;
    }

  }


  move (direction = 'down') {

    if (this.canMove(direction)) {

      if (direction == 'left') {
        this.currentPosition.x -= 1;
        this.mesh.position.x -= this.delta; 
      }

      if (direction == 'right') {
        this.currentPosition.x += 1;
        this.mesh.position.x += this.delta; 
      }

      if (direction == 'up') {
        this.currentPosition.y -= 1;
        this.mesh.position.z -= this.delta; 
      }

      if (direction == 'down') {
        this.currentPosition.y += 1;
        this.mesh.position.z += this.delta; 
      }

      this.level.updateWorld();
      this.level.checkOnLift(this.mesh.position);
      this.level.checkSolved();

    }

  }


  // check if there is an obstacle before moving
  canMove (direction) {

    let targetPosition = Object.assign({}, this.currentPosition); 
        //targetPosition.x = this.mesh.position.x;
        //targetPosition.y = this.mesh.position.y;
        //targetPosition.z = this.mesh.position.z;

    // let targetFrontPosition = new THREE.Vector3(targetPosition.x, targetPosition.y, targetPosition.z); 
    let targetFrontPosition = Object.assign({}, this.currentPosition);
    let pOld = Object.assign({}, targetFrontPosition);


    if (direction == 'left') {
      targetPosition.x -= this.delta;
      targetFrontPosition.x -= this.delta * 2;
    }

    if (direction == 'right') {
      targetPosition.x += this.delta; 
      targetFrontPosition.x += this.delta * 2;
    }

    if (direction == 'up') {
      targetPosition.y -= this.delta; 
      targetFrontPosition.y -= this.delta * 2;
    }

    if (direction == 'down') {
      targetPosition.y += this.delta; 
      targetFrontPosition.y += this.delta * 2;
    }

    console.log('character b', this.currentPosition);

    if (this.level.hasObjectAtPosition(targetPosition, 'wall')) {
      return false;
    }

    if (this.level.hasObjectAtPosition(targetPosition, 'box')) {

      // check if in front of the box is a free place
      if (!this.level.hasObjectAtPosition(targetFrontPosition, 'wall') && !this.level.hasObjectAtPosition(targetFrontPosition, 'box')) {


        // move the box also
        let object = this.level.getObjectAtPosition(targetPosition, 'box');
        let pNew = {
          x: targetFrontPosition.x, 
          y: 0 , 
          z: targetFrontPosition.y 
        }

        this.level.moveObject(object, pOld, pNew);

      } else {

        return false;

      }

    }

    return true;

  }


}