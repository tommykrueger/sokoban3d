import THREE from 'three.js';
import _ from 'underscore';
import Utils from '../app/utils';

// import items
import WallItem from './items/wall';
import TargetItem from './items/target';
import FloorItem from './items/floor';
import BoxItem from './items/box';
import LiftItem from './items/lift';
import Character from './character';


export default class Level {


	constructor (options = {}) {

		this.options = options;
		this.app = this.options.app;
		this.level = this.options.level;

		this.utils = new Utils();

    this.boxes = [];
    this.floors = [];
		this.meshes = [];

    this.targets = 0;

    this.group = new THREE.Group();
    this.floor = new THREE.Group();

    this.group.add(this.floor);
    this.app.scene.add(this.group);

    this.width = options.level.width;
    this.height = options.level.height;

    this.currentFloor = options.level.currentFloor || 0;

    // holds all the three.js items rendered in this level
    this.items = [];

    this.world = { floors: [] };

    this.level.floors.forEach((floor) => {
      this.world.floors.push({ name: floor.name, map: [] });
    });


    this.symbols = {
      '@': 'character',
      '.': 'target',
      '#': 'wall', 
      '-': 'floor', 
      'b': 'box',
      'l': 'lift'
    }
      


		this.materials = {

	  	floor: new THREE.MeshLambertMaterial({
	  		color: 0x666666, 
	  		transparent: false,
	  		opacity: 1,
	  		side: THREE.DoubleSide,
	  		blending: THREE.AdditiveBlending 
	  	})

		};

    this.prepareLevelStructure();
    this.setLevelPosition();
    this.focusFloor();

	}


  prepareLevelStructure() {

    if (this.level.floors) {
      this.level.floors.forEach((floor, index) => {
        let group = new THREE.Object3D()
        this.floors.push(group);
        this.group.add(group);
      });
    }

  }


  setLevelPosition() {
    this.group.position.x -= this.width / 2;
    this.group.position.z -= this.height / 2;

    this.app.camera.lookAt(this.group.position);
  }


  focusFloor () {

    this.floors[this.currentFloor].traverse((child) => {
      if (child instanceof THREE.Mesh) {
        console.log(child);
        child.material.opacity = .1;
      }
    });

  }
 

  render () {

  	if (this.level.floors) {

      this.level.floors.forEach(( floor, index ) => {

        this.floors[index].position.y = index * 5;

    		floor.map.forEach(( row, i ) => {

          // console.log(row, i);

          this.world.floors[index].map.push([]);
    			
    			row.forEach(( col, j ) => {

            let position = new THREE.Vector3(i, 0, j);
            let item;
            let options = {
              app: this.app, 
              level: this, 
              position: position
            };

    				switch(col) {

              case '@':

                item = new Character(options);
                // item.render();
                // item.setPosition(position);

                item.currentPosition.x = i;
                item.currentPosition.y = j;

                this.character = item;

                // this.floors[index].add(this.character.getMesh());
                break;

              case '-':
                item = new FloorItem(options);
                break;

    					case '#':
                item = new WallItem(options);
    						break;

  						case '.':
                item = new TargetItem(options);
                this.targets++;
    						break;

  						case 'b':
                item = new BoxItem(options);
    						break;

              case 'l':
                item = new LiftItem(options);
                this.lift = item;
                break;
    				}


            if (item) {

              item.render();

              this.world.floors[index].map[i].push({
                type: col,
                item: item
              });

              this.meshes.push(item.getMesh());
              this.floors[index].add(item.getMesh());
            }


  				});

  			});  

      });       

  	}

    console.log(this.world);

  }


  /**
   * Animate all the child elements of this level
   */
  animate (clock) {

    this.items.forEach( (item) => {
      if ( typeof(item.animate) === 'function') {
        item.animate(clock);
      }
    });

  }



  /**
   * Afte thee has been an action o any activity in the level
   * we need to update the world
   */
  updateWorld (p1, p2) {

    let temp = this.world.floors[this.currentFloor].map[p1.x][p1.y];
    this.world.floors[this.currentFloor].map[p2.x][p2.y];

  }



  /**
   * Once the corbyn moves to another floor - eg with a lift
   * he enters a new floor
   */
  setFloor (index) {

    this.currentFloor = index;

  }



  hasObjectAtPosition (position, objectType) {

    let object = this.world.floors[this.currentFloor].map[position.x][position.y];

    console.log('item', object);

    if (this.symbols[object.type] == objectType)
      return true

    return false;

  }

  /**
   * Get the item type at a given position
   */
  getObjectAtPosition (position, objectType) {

    let object = this.world.floors[this.currentFloor].map[position.x][position.y];

    if (this.symbols[object.type] == objectType) {
      return object.item;
    }

    return false;

  }


  moveObject (item, targetPosition) {

    // pdate the wold too
    this.level.updateWorld(item);

    item.mesh.position.x = targetPosition.x;
    item.mesh.position.y = targetPosition.y;
    item.mesh.position.z = targetPosition.z;

  }



  checkOnLift (pos) {

    let isOnLift = false;

    this.floors[this.currentFloor].traverse((mesh) => {

      if (mesh.position.distanceTo(pos) == 0 && mesh.objectType == 'lift') {
        isOnLift = true;
      }

    });

    if (isOnLift) {
      this.app.$button.activate();
    } else {
      this.app.$button.deactivate();
    }

  }


  moveToNextFloor () {

    let l = this.floors.length;
    let c = this.currentFloor;

    if (l < c) {
      this.currentFloor++;
    }

    this.lift.move(this.currentFloor * 5);

  }


  checkSolved () {

    let solved = true;
    let targetsWithBoxes = 0;

    this.meshes.forEach((p1) => {

      this.meshes.forEach((p2) => {

        if (p1.objectType == 'target' && p2.objectType == 'box') {

          if (p1.position.distanceTo(p2.position) == 0) {
            targetsWithBoxes++;
          }

        }

      });   

    });  

    if (this.targets === targetsWithBoxes) {
      console.log('level solved ', solved, targetsWithBoxes);
    }

  }


}