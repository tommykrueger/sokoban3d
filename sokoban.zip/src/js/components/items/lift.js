import THREE from 'three.js';

import Item from '../item';

export default class Lift extends Item {


	constructor (options = {}) {

    super(options);

    this.app = options.app;
    this.liftMeshes = [];

		this.material = new THREE.MeshLambertMaterial({
  		color: 0x90ff00, 
  		transparent: false,
  		opacity: 1,
  		side: THREE.DoubleSide,
  		blending: THREE.AdditiveBlending 
  	});

	}
 

  render () {

    this.mesh = new THREE.Mesh(
      new THREE.BoxGeometry(1, .1, 1),
      this.material
    );

    // this.mesh.castShadow = true;
    this.mesh.position.set(this.options.position.x, this.options.position.y, this.options.position.z);
    this.mesh.objectType = 'lift';

  }

  /**
   * find the items that ae on the lift and waiting fo moving
   */
  setItemsInLift () {

    console.log(this.app.level);
    console.log(this.app.level.floors);

    this.liftMeshes = [];

    this.app.level.floors[this.app.level.currentFloor].traverse((mesh) => {
      console.log(mesh, mesh.position.distanceTo(this.mesh));
      if (mesh.position.distanceTo(this.mesh) == 0 && mesh.objectType != 'lift') {
        this.liftMeshes.push(mesh);
      }

    });

    console.log(this.liftMeshes);
  }


  /**
   * move the lift to anothe floo
   */
  move ( posY ) {

    this.setItemsInLift();
    this.mesh.position.y = posY;
    this.liftMeshes.forEach((mesh) => {
      mesh.position.y = posY;
    });

  }


  /**
   * Animate all the child elements of this level
   */
  animate (clock) {}

}