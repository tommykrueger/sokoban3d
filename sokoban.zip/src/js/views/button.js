import View from '../app/view';

export default class Button extends View {
  

  constructor ( options = {} ) {

    super();

    this.app = options.app;
    this.data = options.data;

    this.isActive = false;

    this.$template = $(`<button class="button button-round button-control button-inactive">${this.data.name}</button>`);

    this.render();
    this.initEvents();

  }


  render () {
    
    $('body').append( this.$template );

  }


  initEvents () {


    this.$template.on('click', (e) => {
      
      let $btn = $(e.currentTarget);

      this.app.level.moveToNextFloor();

    });


    this.$template.on('mouseover', (e) => {});
    this.$template.on('mouseout', (e) => {});

  }


  remove () {

    this.$template.remove();

  }


  activate() {

    this.isActive = true;
    this.$template.addClass('button-animated');

  }


  deactivate() {

    this.isActive = false;
    this.$template.removeClass('button-animated');

  }

}